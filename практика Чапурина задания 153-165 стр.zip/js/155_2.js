//2 задание на 155 странице
for (var i = 0; i < 5; i++) {
   fadeTime = (i + 1) * 1000;
   $("h1").fadeOut(fadeTime / 2).fadeIn(fadeTime / 2);
}